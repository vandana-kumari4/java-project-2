import java.util.Scanner;

class Book {
    private String title;
    private String author;
    private boolean isAvailable;

    Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    void displayInfo() {
        System.out.println("Title: " + title + ", Author: " + author + ", Available: " + (isAvailable ? "Yes" : "No"));
    }
}

public class LibraryManagementSystem {
    private static final int MAX_BOOKS = 100;
    private static Book[] books = new Book[MAX_BOOKS];
    private static int count = 0;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("PROJECT BY PUJA BARMAN");
        int choice;
        do {
            displayMenu();
            try {
                choice = Integer.parseInt(scanner.nextLine());
                handleChoice(choice);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number (1-6).");
                choice = 0;
            }
        } while (choice != 6);
    }

    private static void displayMenu() {
        System.out.println("\n--- Library Management System ---");
        System.out.println("1. Add Book");
        System.out.println("2. Display All Books");
        System.out.println("3. Search Book");
        System.out.println("4. Borrow Book");
        System.out.println("5. Return Book");
        System.out.println("6. Exit");
        System.out.print("Enter your choice (1-6): ");
    }

    private static void handleChoice(int choice) {
        switch (choice) {
            case 1: addBook(); break;
            case 2: displayBooks(); break;
            case 3: searchBook(); break;
            case 4: borrowBook(); break;
            case 5: returnBook(); break;
            case 6: System.out.println("Exiting... Thank you for using the Library Management System!"); break;
            default: System.out.println("Invalid choice! Please select 1-6.");
        }
    }

    private static void addBook() {
        if (count >= MAX_BOOKS) {
            System.out.println("Library is full! Cannot add more books.");
            return;
        }
        
        System.out.print("Enter book title: ");
        String title = scanner.nextLine().trim();
        if (title.isEmpty()) {
            System.out.println("Title cannot be empty!");
            return;
        }
        
        System.out.print("Enter author name: ");
        String author = scanner.nextLine().trim();
        if (author.isEmpty()) {
            System.out.println("Author cannot be empty!");
            return;
        }
        
        books[count++] = new Book(title, author);
        System.out.println("Book added successfully!");
    }

    private static void displayBooks() {
        if (count == 0) {
            System.out.println("No books in the library.");
            return;
        }
        System.out.println("\nList of all books:");
        for (int i = 0; i < count; i++) {
            books[i].displayInfo();
        }
    }

    private static void searchBook() {
        System.out.print("Enter title to search: ");
        String searchTitle = scanner.nextLine().trim().toLowerCase();
        boolean found = false;
        
        for (int i = 0; i < count; i++) {
            if (books[i].getTitle().toLowerCase().contains(searchTitle)) {
                books[i].displayInfo();
                found = true;
            }
        }
        if (!found) {
            System.out.println("No books found matching your search.");
        }
    }

    private static void borrowBook() {
        System.out.print("Enter title to borrow: ");
        String title = scanner.nextLine().trim();
        boolean found = false;
        
        for (int i = 0; i < count; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                found = true;
                if (books[i].isAvailable()) {
                    books[i].setAvailable(false);
                    System.out.println("Book borrowed successfully.");
                } else {
                    System.out.println("Book is currently not available.");
                }
                break;
            }
        }
        if (!found) {
            System.out.println("Book not found in the library.");
        }
    }

    private static void returnBook() {
        System.out.print("Enter title to return: ");
        String title = scanner.nextLine().trim();
        boolean found = false;
        
        for (int i = 0; i < count; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                found = true;
                if (!books[i].isAvailable()) {
                    books[i].setAvailable(true);
                    System.out.println("Book returned successfully.");
                } else {
                    System.out.println("This book wasn't borrowed.");
                }
                break;
            }
        }
        if (!found) {
            System.out.println("Book not found in the library.");
        }
    }
}